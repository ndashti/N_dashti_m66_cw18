import React from 'react'
import Counter from './Counter'
export default function CounterParent() {
  return (
    <div>
        <button>Toggle</button>
        <Counter />
    </div>
  )
}
